// aqui se crea el servidor y usa el router
const express=require('express')
const morgan=require('morgan')
const cors=require('cors')
const {router}=require('./routes')

const app=express()

app.use(express.json())// midleware
app.use(morgan('dev'))// midleware
app.use(cors())// midleware

app.use(router)

module.exports={app}