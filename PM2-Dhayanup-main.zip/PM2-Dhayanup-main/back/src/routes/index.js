//PASO 2 EL SERVIDOR USA EL ENRUTADOR, SE ACTIVA. ESTE VERIFICA QUE PUEDE MANEJAR LA SOLICITUD SI ES SI. MANDA A LLAMAR AL CONTROLADOR(getAllMovieController) y este manda a llamr al sevices
const router=require('express').Router()
const {getAllMovieController,postMovieController}=require('../controllers')

// aqui pedimos toda la información de las peliculas
router.get('/movies',getAllMovieController)
router.post('/movies',postMovieController)

module.exports={router}