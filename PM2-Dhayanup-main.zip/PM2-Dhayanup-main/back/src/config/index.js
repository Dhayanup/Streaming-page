require('dotenv').config()
const mongoose=require('mongoose')

const {URI}=process.env;

const connectdb= async ()=>{ //como la DB es externa tenemo que manejar la asincronia
    try {
        await mongoose.connect(URI);
        return 'Conexión exitosa a la base de datos'
    } catch (error) {
        console.log('Error al conectar a la base de datos',error);
    }
}
module.exports={connectdb}