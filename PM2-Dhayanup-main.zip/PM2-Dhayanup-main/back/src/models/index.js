//creando el schema
const mongoose=require('mongoose')
const {Schema, model}=mongoose;

const schemaMovie= new Schema({
    title: {
        type: String,
    required: [true,'el campo es obligatorio']
},
    year: {
        type: Number,
    required: [true,'el campo es obligatorio'],
    min:[1888, 'No hay registro para este año'],
    max: [new Date().getFullYear()+2,'solo hasta dos años']
},
    director: {
        type: String,
        required: [true,'el campo es obligatorio']
    },
    duration:{ 
        type: String,
        validate: {
            validator: function (v) {
        return /^\d{1,2}h\s\d{1,2}min$/.test(v)
            },
            message: (props)=>`${props.value} Se espera un valor XXh XXmin`
        },
        required: [true,'el campo es obligatorio']
    },
    genre:{
        type: [String],
        required: true
    },
    rate: {
        type: Number,
        required: true
    },
    poster: { 
        type: String,
        validate: {
            validator: function (v) {
        return /https?:\/\/.+\.(png|jpe?g)$/.test(v);
            },
            message: (props)=>`${props.value} Introduzca una URL válida`
        },
        required: [true,'el campo es obligatorio']
    },
})

// creación de Modelo

const Movie=model('Movie',schemaMovie)
module.exports={Movie}
