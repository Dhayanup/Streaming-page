const {getAllMovieService,postMovieService}=require('../services')
// paso 3 este manda a llamr al sevices

async function getAllMovieController(req,res) {
    try {
        const response= await getAllMovieService()
        res.send(response)//'Obtener todas las peliculas'
        
    } catch (error) {
        res.send(error)// aqui muestra lo que arrojo el throw porque el si le puede responder al usuario
    }
}

async function postMovieController(req,res) {
    try {
        //ejecuta el servicio y le llega el objeto con la pelicula(req.body)
        const newMovie=await postMovieService(req.body)
        const response={
            message:'Movie creada con éxito',
            status:'ok',
            error:false,
            data:newMovie
        }
        res.status(201).send(response)
    } catch (error) {
        res.send({
            message:'Error al crear la Movie',
            status:'fallido',
            error:true,
            data:error,
        })
    }
}
module.exports={getAllMovieController,postMovieController}

// req=ES LA SOOLICITUD