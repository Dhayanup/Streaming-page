// paso 4  ES AQUI DONDE POR FIN SE LOGRA IR A LA dATA BASE Y TRAERSE LAS PELICULAS Y AHORA NOS DEVOLVEMOS PORQUE EL NO LE RESPONDE AL CLIENTE
const {Movie}=require('../models')

const getAllMovieService=async () => {
    try {
        const resp=await Movie.find()
        console.log(resp);
        return resp;
    } catch (error) {
        console.error(error.message);
        throw error;
        // como el service no debe retornar entonces arrojamos con throw al controller
    }
}


async function postMovieService(movie){ //toma una nueva picula
    try {
        const newMovie=new Movie(movie) //crea una nueva pelicula
        const resp=await newMovie.save() //guarda la pelicula
        console.log(resp); // captura la resp
        
        return resp //la resp, enviamos al controlador
    } catch (error) {
        console.error(error.message);
        throw error;
    }
}

module.exports={getAllMovieService,postMovieService}

// servidor->index->router->controller->SERVICE
    //DEVOLVERSE PARA RESPONDER AL CLIENTE
// servidor<-index<-router<-controller<-SERVICE