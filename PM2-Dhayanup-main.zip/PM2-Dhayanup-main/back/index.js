const {app}=require('./src/server')
const {connectdb}=require('./src/config')
//paso 1 levantar el servidor el se quedara escuchando

const host='localhost'
const port=3000


//la conexion aca para que si sale falla no dejar que el cliente haga solicitud
    connectdb()
    .then((data)=>{
        console.log(data);
        app.listen(port,host, ()=>{
            console.log(`Server listening on http://${host}:${port}`);
        })
    })
    .catch((error)=>{
        console.log(error);
    })

