class CarritoCompra {
    constructor() {
        this.productos=[];
    }
    agregarProducto(producto){
        if(typeof producto === 'object'&& !Array.isArray(producto)){
            this.productos.push(producto)
        }else{
            throw 'Error: El producto debe ser un objeto';
        }
    }
    
    calcularTotal(){
        return this.productos.reduce((acum,elment)=>{return acum+ elment.precio},0);
    }

    aplicarDescuento(porcentaje){
        if(typeof porcentaje !== 'number') throw'Error: debe ser un parámetro númerico';

        if(this.productos.length === 0)throw 'Error: No se debe aplicar descuento, no hay productos';

        const total=this.calcularTotal()
        const descuento=(total*porcentaje)/100
        return total-descuento
    }
}
// lógica BDD
// 1.crea un test
// 2. el test debe fallar y los anteriores no se deben afectar
// crear la lógica ára que pase el test 
// refactorizar


module.exports={CarritoCompra}