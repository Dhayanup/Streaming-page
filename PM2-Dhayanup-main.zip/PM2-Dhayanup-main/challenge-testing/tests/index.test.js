const {CarritoCompra}=require('../src')
let carrito
beforeEach(()=>{
    carrito= new CarritoCompra()
})

describe('Testeando Carrito',()=>{
    test('Validando la instancia de la clase CarritoCompras',()=>{
        expect(carrito).toBeInstanceOf(CarritoCompra)
    })

    test('Validando el método agregarProducto',()=>{
        expect(()=>carrito.agregarProducto('hola')).toThrow('Error: El producto debe ser un objeto');
        
        expect(()=>carrito.agregarProducto(1)).toThrow('Error: El producto debe ser un objeto');

        expect(()=>carrito.agregarProducto([])).toThrow('Error: El producto debe ser un objeto');

        expect(carrito.productos.length).toBe(0)

        expect(carrito.agregarProducto({id:1,nombre:'televisor',cantidad:1,precio:400}))

        expect(carrito.productos.length).toBe(1)
    })
// se le agrega X antes de test para que no lo testee
    test('Validando el método calcularTotal',()=>{
        expect(carrito.calcularTotal).toBeDefined();
        expect(carrito.calcularTotal).toBeInstanceOf(Function);

        carrito.agregarProducto({id:1,nombre:'televisor',cantidad:1,precio:400});

        carrito.agregarProducto({id:2,nombre:'Iphone 16',cantidad:1,precio:1500});

        const total=carrito.calcularTotal();
        expect(total).toBe(1900)
    })

    test('Validando el método aplicarDescuento',()=>{
        expect(carrito.aplicarDescuento).toBeInstanceOf(Function)

        expect(()=>carrito.aplicarDescuento('hola')).toThrow('Error: debe ser un parámetro númerico');

        expect(()=>carrito.aplicarDescuento([])).toThrow('Error: debe ser un parámetro númerico');

        expect(()=>carrito.aplicarDescuento({})).toThrow('Error: debe ser un parámetro númerico')

        expect(()=>carrito.aplicarDescuento(10)).toThrow('Error: No se debe aplicar descuento, no hay productos')

        carrito.agregarProducto({id:1,nombre:'televisor',cantidad:1,precio:400});

        carrito.agregarProducto({id:2,nombre:'Iphone 16',cantidad:1,precio:1500});

        const totalConDescuento=carrito.aplicarDescuento(10)
        expect(totalConDescuento).toBe(1710)
    })
})



       
