const {starGenerator}=require('./starGenerator')

const createCard=(movie)=>{
    const tcard=document.createElement('div')
    tcard.classList.add('tcard')
    
    const titleCard=document.createElement('h2')
    titleCard.innerHTML=movie.title;
    
    const img=document.createElement('img')
    img.src=movie.poster;
    
    [titleCard,img].forEach((elemento)=>{
        tcard.appendChild(elemento)
    })
    
    const curtain=document.createElement('div')
    curtain.classList.add('curtain')
    tcard.appendChild(curtain)
    
    const yearCard=document.createElement('p')
    yearCard.innerHTML=movie.year;
    
    const directorCard=document.createElement('p')
    directorCard.innerHTML=movie.director;

    const durationCard=document.createElement('p')
    durationCard.innerHTML=movie.duration;
    
    const genreCard=document.createElement('p')
    genreCard.innerHTML=movie.genre;
    // para las estrellas modifique para que el numero me quedara redondiado directamente en la variable num
    const rateCard=document.createElement('p')
    const num=Math.round(rateCard.innerHTML=movie.rate);
    // puse la función en una variable para meterla en el forEach y meterla en 'curtain'
    const stars=starGenerator(num);
    
    
    [yearCard,directorCard,durationCard,genreCard,rateCard,stars].forEach((elemento)=>{
    curtain.appendChild(elemento)
    })
    return tcard;
    
    }

module.exports={createCard}