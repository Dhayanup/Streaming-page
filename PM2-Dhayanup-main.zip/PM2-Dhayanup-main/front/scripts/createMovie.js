const axios = require("axios");
let imputTitle, imputPoster, imputYear, imputDirector,imputDuration, imputGenre, imputRate;
const imputsVariables = () => {
  imputTitle = document.getElementById("title");
  imputPoster = document.getElementById("poster");
  imputYear = document.getElementById("year");
  imputDirector = document.getElementById("director");
  imputDuration = document.getElementById("duration");
  imputGenre = document.getElementById("genre");
  imputRate = document.getElementById("rate");
};

const vaciarImputs = () => {
  imputsVariables();

  imputTitle.value = "";
  imputPoster.value = "";
  imputYear.value = "";
  imputDirector.value = "";
  imputDuration.value = "";
  imputGenre.value = "";
  imputRate.value = "";
};

const valideImputs = () => {
  imputsVariables();
  if (
    imputTitle.value &&
    imputPoster.value &&
    imputYear.value &&
    imputDirector.value &&
    imputDuration.value &&
    imputGenre.value &&
    imputRate.value
  ) {
    return true;
  } else {
    alert("Debe llenar todos los campos");
    return false;
  }
};


const createMovie = (event) => {
  event.preventDefault();

  if (valideImputs()) {
    const movie = {
      title: imputTitle.value,
      poster: imputPoster.value,
      year: imputYear.value,
      director: imputDirector.value,
      duration: imputDuration.value,
      genre: imputGenre.value.split(","),
      rate: imputRate.value,
    };
  
  // es peticion externa por tanto manejamos promesa
  axios
  .post("http://localhost:3000/movies", movie)
  .then(({data}) => {
    alert(data.message);
    vaciarImputs();
  })
  .catch((error) => {
    alert(error.message);
    console.log(error);
    
  });
  }
};

const btnCrear = document.getElementById("btnC");
const btnLimpiar = document.getElementById("btnL");

btnCrear.addEventListener("click", createMovie);
btnLimpiar.addEventListener("click", vaciarImputs);

module.exports = { createMovie };



/* if(!title || !year || (year<1888 || year>currentYear) ||!director ||!duration ||!genre ||!rate ||){
  await Swal.fire({
  icon: 'error',
  title: 'error',
  text: 'campo obligatorio',
  showConfirmButton: true,
  })
  return;
  }*/