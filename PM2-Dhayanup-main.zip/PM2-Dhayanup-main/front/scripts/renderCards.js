const {createCard}=require('./createCard')


// le inventamos data como un array que va a recibir para poder mapear
const renderCard=(arrayInventado)=>{
    const contain=document.getElementById('tcontain')
    contain.innerHTML='';
// metemos las tarjetas en el contenedor
const cards= arrayInventado.map(createCard)

cards.forEach(element=> contain.appendChild(element))

} 
module.exports={renderCard}