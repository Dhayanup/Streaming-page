// const tempData = require("./tempData");
const {fetchData}=require('./fetchData')

if(window.location.href.includes('add-Movies.html')){
    require('./createMovie')
}

 const URL='http://localhost:3000/movies';

fetchData(URL);














// $.get(URL,(peli)=>{
    // objetData.forEach((peli) => {//esta la realice con temple String es la misma que la de abajo
    //     renderizado(peli);
    // });

// function renderizado(peli){
//     const container=document.getElementById('tcontain')
//     const tcard=document.createElement('div')
//     tcard.classList.add('tcard')
//     container.appendChild(tcard)

//     tcard.innerHTML=`
//     <h2>${peli.title}</h2>
//     <img src='${peli.poster}' alt='${peli.title}'/>
    
//     <div class="curtain">
//     <p><b>Year:</b>${peli.year}</p>
//     <p><b>director:</b>${peli.director}</p>
//     <p><b>duration:</b>${peli.duration}</p>
//     <p><b>genre:</b>${peli.genre.join(', ')}</p>
//     <p><b>rate:</b>${peli.rate}</p>
//     </div>
//     `
  
// }

