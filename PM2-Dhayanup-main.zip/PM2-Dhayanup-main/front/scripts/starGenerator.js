const star='https://cdn.vectorstock.com/i/500p/93/38/gold-star-icon-single-design-decorative-element-vector-30079338.jpg'

const starGenerator=(ratenumero)=>{
    //se crea el contenedor
    const starcontain=document.createElement('div')
// hice directo los tres métodos de array que nesecitaba
Array(ratenumero).fill().map(()=>{
    // uso del DOM para pasar las de elementos de un array a los de una imagen que se muestra
    const img=document.createElement('img')
    img.style.width='23px';
    img.style.height='23px';
    img.src=star;
    return img
}).forEach((star)=>{
    //tomo este método para meterlas en el contenedor creado
    starcontain.appendChild(star)
})
//se retorna el contenedor para usarla arriba a traves de la función
return starcontain
}

module.exports={starGenerator}