// const { createCard } = require('./createCard')
const {renderCard}=require('./renderCards')
const axios=require('axios')

//////////// con promesa y con async/awiat
const fetchData=async(URL)=>{

    try {
        const response=await axios.get(URL)
        console.log(response.data)
        renderCard(response.data)
        
        
    } catch (error) {
        console.log(error.message);
        
    }
    

    


    // promise
    // .then((res)=>{
    // console.log(res.data)
    // renderCard(res.data)
    // })
    // .catch((error)=>{
    // console.log(error);
    // })
}

module.exports={fetchData};


// const fetchData=(URL)=>{

//     $.get(URL,(objetData)=>{
//             renderCard(objetData);
//     }).fail(()=>{
//         alert('Error al obtener listado');
//     });
// };